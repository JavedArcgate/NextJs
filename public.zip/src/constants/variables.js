/**
* This file  is used define all constants and variables.
*/

// Colors
export const brandColor = '#EC994B';

// Success Messages
export const emailRegistered = 'Your email is registered with our newsletter!!';
// Error Messages
export const erEmail = 'Invalid/Duplicate email!!';
export const erFood = 'Please enter food name and price!!';
