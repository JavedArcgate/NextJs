const INCREMENT = "INCREMENT"

function incrementCounter() {
  return{
    type: INCREMENT
  }
}