import React from "react";

export default function Logo({  }) {
  return (
    <a className="navbar-brand fw-bold brand-color" href="#">
      SKLU Cabs
    </a>
  );
}
